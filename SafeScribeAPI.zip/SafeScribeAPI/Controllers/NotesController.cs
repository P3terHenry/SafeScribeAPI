﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SafeScribeAPI.Data;
using SafeScribeAPI.DTOs;
using SafeScribeAPI.Models;
using System.Security.Claims;

namespace SafeScribeAPI.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    [Authorize]
    public class NotesController : ControllerBase
    {
        private readonly AppDbContext _db;

        public NotesController(AppDbContext db)
        {
            _db = db;
        }

        // 🔹 Criar nota (apenas Editor ou Admin)
        [HttpPost]
        [Authorize(Roles = "Editor,Admin")]
        public async Task<IActionResult> Criar([FromBody] NoteCreateDto dto)
        {
            var userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? string.Empty);
            var note = new Note
            {
                Title = dto.Title,
                Content = dto.Content,
                UserId = userId
            };

            _db.Notes.Add(note);
            await _db.SaveChangesAsync();

            return Ok(note);
        }

        // 🔹 Buscar nota por ID
        [HttpGet("{id}")]
        public async Task<IActionResult> Obter(Guid id)
        {
            var note = await _db.Notes.FindAsync(id);
            if (note == null) return NotFound();

            var userRole = User.FindFirstValue(ClaimTypes.Role);
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // 🔒 Permissão: Leitor e Editor só acessam as próprias notas
            if (userRole != "Admin" && note.UserId.ToString() != userId)
                return Forbid();

            return Ok(note);
        }

        // 🔹 Atualizar nota (Editor pode editar a sua / Admin pode editar qualquer)
        [HttpPut("{id}")]
        [Authorize(Roles = "Editor,Admin")]
        public async Task<IActionResult> Atualizar(Guid id, [FromBody] NoteUpdateDto dto)
        {
            var note = await _db.Notes.FindAsync(id);
            if (note == null) return NotFound();

            var userRole = User.FindFirstValue(ClaimTypes.Role);
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userRole != "Admin" && note.UserId.ToString() != userId)
                return Forbid();

            note.Title = dto.Title;
            note.Content = dto.Content;
            await _db.SaveChangesAsync();

            return Ok(note);
        }

        // 🔹 Deletar nota (somente Admin)
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Deletar(Guid id)
        {
            var note = await _db.Notes.FindAsync(id);
            if (note == null) return NotFound();

            _db.Notes.Remove(note);
            await _db.SaveChangesAsync();

            return Ok(new { message = "Nota removida com sucesso." });
        }
    }
}
