﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SafeScribeAPI.DTOs;
using SafeScribeAPI.Services;
using System.IdentityModel.Tokens.Jwt;

namespace SafeScribeAPI.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ITokenService _tokenService;
        private readonly ITokenBlacklistService _blacklist;

        public AuthController(ITokenService tokenService, ITokenBlacklistService blacklist)
        {
            _tokenService = tokenService;
            _blacklist = blacklist;
        }

        /// <summary>
        /// Registro de novo usuário
        /// </summary>
        [HttpPost("registrar")]
        [AllowAnonymous]
        public async Task<IActionResult> Registrar([FromBody] UserRegisterDto dto)
        {
            var user = await _tokenService.RegisterAsync(dto.Username, dto.Password, dto.Role);
            return Ok(new
            {
                message = "Usuário registrado com sucesso.",
                user = new { user.Id, user.Username, user.Role }
            });
        }

        /// <summary>
        /// Login e geração do token JWT
        /// </summary>
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto dto)
        {
            var (user, token, expiresAtUtc) = await _tokenService.LoginAsync(dto.Username, dto.Password);

            return Ok(new TokenResponseDto
            {
                Token = token,
                ExpiresAtUtc = expiresAtUtc,
                Username = user.Username,
                Role = user.Role.ToString()
            });
        }

        /// <summary>
        /// Logout: adiciona o token atual na blacklist
        /// </summary>
        [HttpPost("logout")]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            var jti = User.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Jti)?.Value;

            if (jti != null)
            {
                await _blacklist.AddToBlacklistAsync(jti);
                return Ok(new { message = "Logout realizado com sucesso. Token invalidado." });
            }

            return BadRequest(new { error = "Token inválido." });
        }
    }
}
