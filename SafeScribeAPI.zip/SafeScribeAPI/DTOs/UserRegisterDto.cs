﻿using SafeScribeAPI.Models;
using System.ComponentModel.DataAnnotations;

namespace SafeScribeAPI.DTOs
{
    public class UserRegisterDto
    {
        [Required]
        [MinLength(3)]
        public string Username { get; set; } = string.Empty;

        [Required]
        [MinLength(6)]
        public string Password { get; set; } = string.Empty;

        [Required]
        public Role Role { get; set; }
    }
}
