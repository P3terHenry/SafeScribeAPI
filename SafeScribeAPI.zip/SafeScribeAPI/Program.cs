using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using SafeScribeApi.Middleware;
using SafeScribeAPI.Data;
using SafeScribeAPI.Services;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// ?? 1. Configura o EF Core com banco em mem�ria
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("SafeScribeDb"));

// ?? 2. Injeta os servi�os
builder.Services.AddScoped<ITokenService, TokenService>();
builder.Services.AddSingleton<ITokenBlacklistService, InMemoryTokenBlacklistService>();

// ?? 3. Configura��o do JWT
var jwtSection = builder.Configuration.GetSection("Jwt");
var issuer = jwtSection["Issuer"];
var audience = jwtSection["Audience"];
var secret = jwtSection["Secret"] ?? throw new InvalidOperationException("?? Jwt:Secret n�o configurado!");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,              // ? garante que o emissor do token � confi�vel
            ValidateAudience = true,            // ? garante que o p�blico-alvo est� correto
            ValidateLifetime = true,            // ? garante que o token n�o est� expirado
            ValidateIssuerSigningKey = true,    // ? garante que a assinatura � v�lida
            ValidIssuer = issuer,
            ValidAudience = audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret)),
            ClockSkew = TimeSpan.Zero           // ? expira��o exata sem toler�ncia extra
        };
    });

// ?? 4. Autoriza��o baseada em Roles
builder.Services.AddAuthorization();

// ?? 5. Configura Swagger com suporte a Bearer Token
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "SafeScribe API",
        Version = "v1",
        Description = "API de gest�o de notas com autentica��o JWT e controle de acesso por roles."
    });

    // ?? Configura��o do bot�o "Authorize" no Swagger
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Insira o token JWT com 'Bearer ' no in�cio. Ex: Bearer eyJhbGciOiJIUzI1...",
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

// ?? 6. Swagger no ambiente de desenvolvimento
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "SafeScribe API v1");
        c.DocumentTitle = "SafeScribe API Docs";
    });
}

app.UseHttpsRedirection();

// ?? 7. Ordem correta do pipeline
app.UseAuthentication();                     // ? Autentica��o primeiro
app.UseMiddleware<JwtBlacklistMiddleware>(); // ? Blacklist vem logo depois
app.UseAuthorization();                      // ? Depois vem autoriza��o

app.MapControllers();

app.Run();